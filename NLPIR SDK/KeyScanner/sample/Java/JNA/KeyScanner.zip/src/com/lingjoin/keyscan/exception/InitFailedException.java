package com.lingjoin.keyscan.exception;

public class InitFailedException extends Exception {

	private static final long serialVersionUID = 7461702891545886318L;

	public InitFailedException(String msg){
		super(msg);
	}
}
