# KeyScanner
敏感词扫面程序，基于Linux/Windows算法库的Java版本

--Dictionary File Path: Data

--Resources/Eclipse's Source Folder: Linux/Windows X86/64 Dynamic Library

--Java Test Class:
	com.lingjoin.keyscan.test.KeyScannerTest